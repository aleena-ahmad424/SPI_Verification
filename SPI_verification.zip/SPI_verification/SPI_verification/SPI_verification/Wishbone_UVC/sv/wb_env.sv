class wb_env extends uvm_env;

  //Agent handle
  wb_agent agent;

  //Factory registration
  `uvm_component_utils(wb_env)

  //Constructor
  function new(string name = "wb_env", uvm_component parent);
    super.new(name, parent);
  endfunction

  //Build phase
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    //Construct the agent
    agent = wb_agent::type_id::create("agent", this);
  endfunction

  function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
endfunction

endclass