class wb_monitor extends uvm_monitor;

//Declare handles
virtual wb_if vif;
wb_transaction tr;
int num_tr_col;
spi_mode_config mode_cfg;
uvm_event spi_start_event;

//Analysis port to send transactions to subscribers  
uvm_analysis_port #(wb_transaction) item_collected_port;

  `uvm_component_utils(wb_monitor)

  function new(string name = "wb_monitor", uvm_component parent);
    super.new(name, parent);

    item_collected_port = new("item_collected_port", this);

  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    
    //Get the SPI mode configuration from the UVM configuration database
    if(!uvm_config_db#(spi_mode_config)::get(this, "", "mode_cfg", mode_cfg))
      `uvm_error("NO_CFG","SPI mode config not found")

    if(!uvm_config_db#(uvm_event)::get(this, "", "spi_start_event", spi_start_event))
      `uvm_error("NO_EVENT","No event found")
  endfunction

  function void connect_phase(uvm_phase phase);

    super.connect_phase(phase);

    if (!wb_vif_config::get(this, "", "vif", vif))
     `uvm_error("NOVIF", "vif not set")

  endfunction

  task run_phase(uvm_phase phase);

   //Wait for reset to be deasserted
    wait (vif.rst==0);

    `uvm_info(get_type_name(), "Detected Reset Done", UVM_MEDIUM)

    forever begin

      @(posedge vif.clk);
      tr = wb_transaction::type_id::create("tr", this);

      if (vif.cyc && vif.stb && vif.ack) begin
        //Capture the address and write enable from the interface signals
        tr.we_i  = vif.we;
        tr.adr_i = addr_type'(vif.addr);

        //Write data to if write enable is high, else read data, and assign ack and inta signals
        if (vif.we)
          tr.dat_i = vif.wr_data;
        else
          tr.dat_o = vif.rd_data;

        tr.ack_o = vif.ack;
        tr.inta_o = vif.inta;
        
        //If write enable is high and address is SPCR, update the SPI mode configuration based on the transaction data
        if(tr.we_i && tr.adr_i == SPCR) begin
          mode_cfg.cpol = tr.dat_i[3];
          mode_cfg.cpha = tr.dat_i[2];
        end

      `uvm_info(get_type_name(), $sformatf("Transaction Collected:\n%s", tr.sprint()), UVM_LOW)

      //Send the collected transaction to the analysis port and increment the transaction count          
      item_collected_port.write(tr);
      
      if(tr.we_i && tr.adr_i == SPDR)
      spi_start_event.trigger();
      
      num_tr_col++;

      end
  end

  endtask

  function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
  endfunction

  // UVM report_phase
  function void report_phase(uvm_phase phase);
    `uvm_info(get_type_name(), $sformatf("Report: WB Monitor Collected %0d Transactions", num_tr_col), UVM_LOW)
  endfunction

endclass