typedef enum bit [3:0] {SPCR, SPSR, SPDR, SPER} addr_type;
class wb_transaction extends uvm_sequence_item;
rand addr_type adr_i;
rand bit [7:0] dat_i;
rand bit we_i;

bit [7:0] dat_o;
bit ack_o;
bit inta_o;

`uvm_object_utils_begin(wb_transaction)
  `uvm_field_enum(addr_type, adr_i, UVM_ALL_ON)
  `uvm_field_int(dat_i, UVM_ALL_ON)
  `uvm_field_int(we_i, UVM_ALL_ON)
  `uvm_field_int(dat_o, UVM_ALL_ON)
  `uvm_field_int(ack_o, UVM_ALL_ON)
  `uvm_field_int(inta_o, UVM_ALL_ON)
`uvm_object_utils_end

function new(string name = "Wb transaction");
    super.new(name);
endfunction

//Defining constraints for bit 5 of SPCR to be 0 when writing to this register
constraint spcr_write_c {
    if(adr_i == SPCR && we_i)
        dat_i[5] == 0;
}

//Defining constraints for bit 5 to 2 of SPER to be 0 when writing to this register
constraint sper_write_c {
    if(adr_i == SPER && we_i)
        dat_i[5:2] == 0;
}  

//Defining constraints for SPSR to be read only
constraint spsr_write_c {
    if(adr_i == SPSR && we_i)
        dat_i[5:0] == 0;
}

//Defining constraints for bit 4 of SPCR to be 1 when writing to this register (always master mode)
constraint spcr_mstr_c {
    if(adr_i == SPCR && we_i)
        dat_i[4] == 1;
}

constraint sper_c_clk {
    if(adr_i == SPER && we_i)
        dat_i[7:6] != 2'b11;
}
endclass