class wb_driver extends uvm_driver #(wb_transaction);

virtual wb_if vif;
int num_sent;

  `uvm_component_utils(wb_driver)

  function new(string name = "wb_driver", uvm_component parent);
    super.new(name, parent);
  endfunction

function void connect_phase(uvm_phase phase);

  super.connect_phase(phase);
  
  //getting config for virtual interface
  if (!wb_vif_config::get(this, "", "vif", vif))
    `uvm_error("NOVIF", "vif not set")

endfunction

task run_phase(uvm_phase phase);
    fork
      get_and_drive();
      reset_signals();
    join
endtask

  //Gets transaction from the sequencer and passes them to the driver. 
  task get_and_drive();

  //Wait for reset to be de-asserted
  wait (vif.rst == 0);
  `uvm_info(get_type_name(), "Reset dropped", UVM_LOW)
    
    forever 
      begin

      //Get transaction from sequencer
      seq_item_port.get_next_item(req);

      `uvm_info(get_type_name(), $sformatf("Sending Transaction :\n%s", req.sprint()), UVM_HIGH)
 
      //Check if the transaction is a write or read and call the appropriate method
      if (req.we_i)
        vif.wb_write(req.adr_i, req.dat_i);
      else
        vif.wb_read(req.adr_i, req.dat_o); 
      
      //Increment the number of transactions sent
      num_sent++;

      //Inform the sequencer that the transaction is done
      seq_item_port.item_done();
      end
  endtask

//Reset task
  task reset_signals();
    forever 
    //Reset the signals
     vif.wb_reset();
  endtask

function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info(get_type_name(), $sformatf("Report: WB driver sent %0d transactions", num_sent), UVM_LOW)
  endfunction

endclass