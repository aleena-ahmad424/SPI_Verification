class wb_sequencer extends uvm_sequencer #(wb_transaction);

  // Factory registration
  `uvm_component_utils(wb_sequencer)
  virtual wb_if vif;

  // Constructor
  function new(string name = "wb_sequencer", uvm_component parent);
    super.new(name, parent);
  endfunction
  
 function void build_phase(uvm_phase phase);
    super.build_phase(phase); 
  if (!wb_vif_config::get(this, "", "vif", vif))
    `uvm_error("NOVIF", "vif not set")
  endfunction

  function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
endfunction

endclass