class wb_agent extends uvm_agent;

  //Component handles
  wb_monitor   monitor;
  wb_driver    driver;
  wb_sequencer sequencer;

  //Factory registration and field automation
  `uvm_component_utils_begin(wb_agent)
    `uvm_field_enum(uvm_active_passive_enum, is_active, UVM_ALL_ON)
  `uvm_component_utils_end

  //Constructor
  function new(string name = "wb_agent",
               uvm_component parent);
    super.new(name, parent);
  endfunction

  //Build phase
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    //Monitor always exists
    monitor = wb_monitor::type_id::create("monitor", this);

    //Driver and sequencer only for active agents
    if (is_active == UVM_ACTIVE) begin
      driver = wb_driver::type_id::create("driver", this);

      sequencer = wb_sequencer::type_id::create("sequencer", this);
    end
  endfunction

  //Connect phase
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    if (is_active == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
    end
  endfunction

  function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
endfunction

endclass