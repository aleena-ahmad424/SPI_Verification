  import uvm_pkg::*;
interface wb_if(input logic clk, input logic rst);
import wb_pkg::*;

  logic       cyc;         // cycle
  logic       stb;         // strobe
  logic [1:0] addr;         // address
  logic       we;          // write enable
  logic [7:0] wr_data;         // data input
  logic [7:0] rd_data;         // data output
  logic       ack;         // normal bus termination
  logic       inta;        // interrupt output


  task wb_reset();

  //wait for reset to be high, then reset the signals
  wait(rst==1);

  addr    <= '0;
  wr_data <= '0;
  we      <= 1'b0;
  cyc     <= 1'b0;
  stb     <= 1'b0;

  @(negedge rst);

  endtask

  //Write data on positive edge of clock, wait for ack, then reset signals
  task wb_write(input addr_type addr_t, input bit [7:0] wr_data_t);
  @(posedge clk);
  addr = addr_t;
  wr_data = wr_data_t;
  we = 1;
  cyc = 1;
  stb = 1;

  wait (ack);

  @(posedge clk);

  we = 0;
  cyc = 0;
  stb = 0;

  endtask
  
  //Read data on positive edge of clock, wait for ack, then reset signals
  task wb_read(input addr_type addr_t, output bit [7:0] rd_data_t);
  @(posedge clk);
  addr <= addr_t;
  we <= 0;
  cyc <= 1;
  stb <= 1;

  wait (ack);
  
  rd_data_t = rd_data;

  @(posedge clk);
  cyc <= 0;
  stb <= 0;
  endtask
endinterface

