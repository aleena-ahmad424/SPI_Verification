
package wb_pkg;
import uvm_pkg::*;
import spi_comm_pkg::*;
`include "uvm_macros.svh"
typedef uvm_config_db#(virtual wb_if) wb_vif_config;
`include "wb_transaction.sv"
`include "wb_monitor.sv"
`include "wb_sequencer.sv"
`include "wb_seqs.sv"
`include "wb_driver.sv"
`include "wb_agent.sv"
`include "wb_env.sv"

endpackage