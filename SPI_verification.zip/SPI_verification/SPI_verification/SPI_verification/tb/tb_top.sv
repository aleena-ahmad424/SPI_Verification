module tb_top;

  // Import UVM library
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  import wb_pkg::*;
  import spi_pkg::*;
  import spi_comm_pkg::*;

  `include "spi_mcsequencer.sv"
  `include "spi_tb.sv"
  `include "spi_simple_mcseq.sv"
  `include "spi_test_lib.sv" 

  hw_top hw_top();

  initial begin
    //Set up the SPI mode configuration and virtual interfaces in the UVM configuration database
  spi_mode_config mode_cfg;

    mode_cfg = spi_mode_config::type_id::create("mode_cfg");

    uvm_config_db#(spi_mode_config)::set(null, "*", "mode_cfg", mode_cfg);
    wb_vif_config::set(null, "*.tb.wb.agent.*", "vif", hw_top.wb0);
    spi_vif_config::set(null, "*.tb.spi.agent.*", "vif", hw_top.spi0);
    
    run_test();

  end

endmodule