class base_test extends uvm_test;

  `uvm_component_utils(base_test)

  function new(string name = "base_test", uvm_component parent);
    super.new(name, parent);
  endfunction

spi_tb tb;

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    uvm_config_int::set(this, "*", "recording_detail", 1);

    tb = spi_tb::type_id::create("tb", this);

    `uvm_info(get_type_name(), "Executing spi_test_lib build_phase()", UVM_HIGH)
  endfunction

  task run_phase(uvm_phase phase);

  uvm_objection obj;

  super.run_phase(phase);

  obj = phase.get_objection();

  obj.set_drain_time(this, 400ns);

endtask

  function void end_of_elaboration_phase(uvm_phase phase);
  uvm_top.print_topology();
  endfunction

  function void check_phase(uvm_phase phase);
  super.check_phase(phase);

  check_config_usage();
endfunction

endclass

//SPCR, SPER write test
class wb_write_seq_test extends base_test;

  `uvm_component_utils(wb_write_seq_test)

  function new(string name="wb_write_seq_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "*.wb.agent.sequencer.run_phase", "default_sequence", wb_write_seq::type_id::get());

  endfunction
endclass

//SPI transfer with mode configuration test
class wb_write_slave_seq_test extends base_test;

  `uvm_component_utils(wb_write_slave_seq_test)

  function new(string name="wb_write_slave_seq_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "tb.mcsequencer.run_phase", "default_sequence", spi_simple_mcseq_mode::type_id::get());

  endfunction
endclass

//SPI transfer with interrupt test
class spi_interrupt_seq_test extends base_test;

  `uvm_component_utils(spi_interrupt_seq_test)

  function new(string name="spi_interrupt_seq_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "tb.mcsequencer.run_phase", "default_sequence", spi_simple_mcseq_inter::type_id::get());

  endfunction
endclass

//SPI transfer with clock frequency test
class clkfreq_test_seq_test extends base_test;

  `uvm_component_utils(clkfreq_test_seq_test)

  function new(string name="clkfreq_test_seq_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "tb.mcsequencer.run_phase", "default_sequence", spi_simple_mcseq_clk::type_id::get());

  endfunction
endclass

//SPI transfer with multibyte test
class multi_test extends base_test;

  `uvm_component_utils(multi_test)

  function new(string name="multi_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "tb.mcsequencer.run_phase", "default_sequence", spi_simple_mcseq_mult::type_id::get());

  endfunction
endclass

//SPI transfer with FIFO write full test
class fifo_wfull_seq_test extends base_test;

  `uvm_component_utils(fifo_wfull_seq_test)

  function new(string name="fifo_wfull_seq_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "*.wb.agent.sequencer.run_phase", "default_sequence", fifo_wfull_test_seq::type_id::get());

  endfunction
endclass

//SPI transfer with FIFO read full test
class fifo_rfull_test extends base_test;

  `uvm_component_utils(fifo_rfull_test)

  function new(string name="fifo_rfull_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set( this, "tb.mcsequencer.run_phase", "default_sequence", spi_simple_mcseq_rfifo::type_id::get());

  endfunction
endclass

//SPI transfer with FIFO write collision test
class fifo_wcol_seq_test extends base_test;

  `uvm_component_utils(fifo_wcol_seq_test)

  function new(string name="fifo_wcol_seq_test", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_config_wrapper::set(this, "*.wb.agent.sequencer.run_phase", "default_sequence", fifo_wcol_test_seq::type_id::get());

  endfunction
endclass