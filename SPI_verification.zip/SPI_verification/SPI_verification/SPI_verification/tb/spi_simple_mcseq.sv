//Multichannel sequence for SPI transfer
class spi_simple_mcseq_mode extends uvm_sequence;

  `uvm_object_utils(spi_simple_mcseq_mode)

  `uvm_declare_p_sequencer(spi_mcsequencer)

  spi_seq spi_seq_mt;
  spi_master_transfer_seq  spi_mt_seq;

virtual task body();

  if (starting_phase != null)
    starting_phase.raise_objection(this);

  spi_seq_mt = spi_seq::type_id::create("spi_seq_mt");
  spi_mt_seq = spi_master_transfer_seq::type_id::create("spi_mt_seq");

  fork
    spi_mt_seq.start(p_sequencer.wb_seqr);
    spi_seq_mt.start(p_sequencer.spi_seqr);
  join

  if (starting_phase != null)
    starting_phase.drop_objection(this);

endtask

endclass

//Multichannel sequence for SPI transfer with interrupt
class spi_simple_mcseq_inter extends uvm_sequence;

  `uvm_object_utils(spi_simple_mcseq_inter)

  `uvm_declare_p_sequencer(spi_mcsequencer)

  spi_seq spi_seq_i;
  spi_interrupt_seq  spi_int_seq;

virtual task body();

  if (starting_phase != null)
    starting_phase.raise_objection(this);

  spi_seq_i = spi_seq::type_id::create("spi_seq_i");
  spi_int_seq = spi_interrupt_seq::type_id::create("spi_int_seq");

  fork
    spi_int_seq.start(p_sequencer.wb_seqr);
    spi_seq_i.start(p_sequencer.spi_seqr);
  join

  if (starting_phase != null)
    starting_phase.drop_objection(this);

endtask

endclass

//Multichannel sequence for SPI transfer with clock frequency test
class spi_simple_mcseq_clk extends uvm_sequence;

  `uvm_object_utils(spi_simple_mcseq_clk)

  `uvm_declare_p_sequencer(spi_mcsequencer)

  spi_seq spi_seq_clk;
  clkfreq_test_seq  spi_clk_seq;

virtual task body();

  if (starting_phase != null)
    starting_phase.raise_objection(this);

  spi_seq_clk = spi_seq::type_id::create("spi_seq_clk");
  spi_clk_seq = clkfreq_test_seq::type_id::create("spi_clk_seq");

  fork
    spi_clk_seq.start(p_sequencer.wb_seqr);
    spi_seq_clk.start(p_sequencer.spi_seqr);
  join

  if (starting_phase != null)
    starting_phase.drop_objection(this);

endtask

endclass

//Multichannel sequence for SPI transfer with multiple transfers
class spi_simple_mcseq_mult extends uvm_sequence;

  `uvm_object_utils(spi_simple_mcseq_mult)

  `uvm_declare_p_sequencer(spi_mcsequencer)

  spi_seq spi_m_seq;
  mult_test_seq  spi_mt_seq;

virtual task body();

  if (starting_phase != null)
    starting_phase.raise_objection(this);

  spi_m_seq = spi_seq::type_id::create("spi_m_seq");
  spi_mt_seq = mult_test_seq::type_id::create("spi_mt_seq");

  fork
    spi_mt_seq.start(p_sequencer.wb_seqr);
    spi_m_seq.start(p_sequencer.spi_seqr);
  join

  if (starting_phase != null)
    starting_phase.drop_objection(this);

endtask

endclass

//Multichannel sequence for SPI transfer with FIFO read full test
class spi_simple_mcseq_rfifo extends uvm_sequence;

  `uvm_object_utils(spi_simple_mcseq_rfifo)

  `uvm_declare_p_sequencer(spi_mcsequencer)

  spi_seq spi_m_seq;
  fifo_rfull_test_seq  spi_ff_seq;

virtual task body();

  if (starting_phase != null)
    starting_phase.raise_objection(this);

  spi_m_seq = spi_seq::type_id::create("spi_m_seq");
  spi_ff_seq = fifo_rfull_test_seq::type_id::create("spi_ff_seq");

  fork
    spi_ff_seq.start(p_sequencer.wb_seqr);
    spi_m_seq.start(p_sequencer.spi_seqr);
  join

  if (starting_phase != null)
    starting_phase.drop_objection(this);

endtask

endclass