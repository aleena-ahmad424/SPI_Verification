//Stores SPI mode configuration so they can be shared amongst SPI driver and monitor
package spi_comm_pkg;
import uvm_pkg::*;
`include "uvm_macros.svh"
class spi_mode_config extends uvm_object;

  bit cpol;
  bit cpha;

  `uvm_object_utils(spi_mode_config)

  function new(string name="spi_mode_config");
    super.new(name);
  endfunction

endclass
endpackage