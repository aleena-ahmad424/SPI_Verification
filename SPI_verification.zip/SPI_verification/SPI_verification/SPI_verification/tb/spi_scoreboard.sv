import spi_pkg::*;
import wb_pkg::*;

//Analysis implementation declarations
`uvm_analysis_imp_decl(_wb_mon)
`uvm_analysis_imp_decl(_spi)
`uvm_analysis_imp_decl(_spi_driv)

class spi_scoreboard extends uvm_scoreboard;
  uvm_analysis_imp_wb_mon #(wb_transaction, spi_scoreboard) wb_mon_imp;

  uvm_analysis_imp_spi #(spi_transaction, spi_scoreboard) spi_imp;

  uvm_analysis_imp_spi_driv #(spi_transaction, spi_scoreboard) spi_driv_imp;                       

  `uvm_component_utils(spi_scoreboard)

//To store expected values for comparison
  bit [7:0] exp_mosi_q[$];
  bit [7:0] exp_miso_q[$];
  spi_transaction pending_spi_q[$];

//Pass/fail counters
  int pass_cnt;
  int fail_cnt;

//Constructor
  function new(string name="spi_scoreboard", uvm_component parent);
    super.new(name,parent);

    wb_mon_imp  = new("wb_mon_imp",this);
    spi_imp = new("spi_imp",this);
    spi_driv_imp  = new("spi_driv_imp",this);

  endfunction

//Write methods for analysis ports (WB monitor, SPI monitor, SPI driver)
function void write_wb_mon(wb_transaction tr);

//Store ecpected MOSI values for comparison and call comparison function
  if(tr.we_i && tr.adr_i == SPDR)
    exp_mosi_q.push_back(tr.dat_i);  
  comp();

//Check SPSR read
  if(!tr.we_i && tr.adr_i == SPSR)
  begin

//Check SPIF flag and interrupt assertion
    if(tr.dat_o[7])
      `uvm_info("INT_SB", "SPIF flag PASS", UVM_LOW)
    else
      `uvm_info("INT_SB", "SPIF flag not set", UVM_LOW)

//Check interrupt assertion
    if(tr.inta_o)
      `uvm_info("INT_SB", "Interrupt PASS", UVM_LOW)
    else
      `uvm_info("INT_SB", "Interrupt not asserted", UVM_LOW)

//Check FIFO status flags
    if(tr.dat_o[6])
      `uvm_info("FIFO_SB","WCOL Flag set",UVM_LOW)
  
    if(tr.dat_o[3])
      `uvm_info("FIFO_SB","Write FIFO full",UVM_LOW)

    if(tr.dat_o[2])
     `uvm_info("FIFO_SB","Write FIFO empty",UVM_LOW)

    if(tr.dat_o[1])
      `uvm_info("FIFO_SB","Read FIFO full",UVM_LOW)

    if(tr.dat_o[0])
      `uvm_info("FIFO_SB","Read FIFO empty",UVM_LOW)

  end
  
endfunction

function void write_spi_driv(spi_transaction tr);

//Store expected MISO values for comparison and call comparison function
  exp_miso_q.push_back(tr.tx_data);
  comp();
endfunction


function void write_spi(spi_transaction tr);

//Store pending SPI transactions for comparison and call comparison function
pending_spi_q.push_back(tr);
comp();

endfunction

function void comp();

//Compare expected and actual values for MOSI and MISO
  spi_transaction tr;
  bit [7:0] exp_mosi;
  bit [7:0] exp_miso;

//Ensure queues are not empty before popping values for comparison
  while(pending_spi_q.size() > 0 &&
        exp_mosi_q.size() > 0 &&
        exp_miso_q.size() > 0)
  begin

    //Pop values from queues for comparison
    tr = pending_spi_q.pop_front();
    exp_mosi = exp_mosi_q.pop_front();
    exp_miso = exp_miso_q.pop_front();

    //Compare expected and actual values for MOSI and MISO
    if(exp_mosi == tr.rx_data)
    begin
      pass_cnt++;
      `uvm_info("SPI_SB", $sformatf("MOSI PASS Expected=%02h Actual=%02h", exp_mosi,tr.rx_data), UVM_LOW)
    end

    else
    begin
      fail_cnt++;
      `uvm_error("SPI_SB", $sformatf("MOSI FAIL Expected=%02h Actual=%02h", exp_mosi,tr.rx_data))
    end

    if(exp_miso == tr.tx_data)
    begin
      pass_cnt++;
      `uvm_info("SPI_SB", $sformatf("MISO PASS Expected=%02h Actual=%02h", exp_miso,tr.tx_data), UVM_LOW)
    end

    else
    begin
      fail_cnt++;
      `uvm_error("SPI_SB", $sformatf("MISO FAIL Expected=%02h Actual=%02h", exp_miso,tr.tx_data))
    end

  end

endfunction

function void report_phase(uvm_phase phase);

  `uvm_info("SPI_SB", $sformatf("PASS=%0d FAIL=%0d", pass_cnt,fail_cnt), UVM_LOW)

endfunction  

endclass