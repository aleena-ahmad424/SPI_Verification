module hw_top;

  logic clock;
  logic reset;

  wb_if  wb0(clock, reset);
  spi_if spi0(clock, reset);

//Clock generator
  clkgen clkgen(
    .clock(clock)
  );

  //Assert reset for 50ns
  initial begin
    reset = 1'b1;
    #50;
    reset = 1'b0;
  end

  simple_spi dut(

    .clk_i (clock),
    .rst_i (reset),

    //Wishbone
    .cyc_i (wb0.cyc),
    .stb_i (wb0.stb),
    .adr_i (wb0.addr),
    .we_i  (wb0.we),
    .dat_i (wb0.wr_data),

    .dat_o (wb0.rd_data),
    .ack_o (wb0.ack),
    .inta_o(wb0.inta),

    //SPI
    .sck_o (spi0.sck),
    .mosi_o(spi0.mosi),
    .miso_i(spi0.miso)

  );

endmodule