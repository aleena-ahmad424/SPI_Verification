
class spi_tb extends uvm_env;

  //Declare handles for the environments, scoreboard and sequencer
  wb_env wb;
  spi_env spi;
  spi_scoreboard sb;
  spi_mcsequencer mcsequencer;
  uvm_event spi_start_event;
  `uvm_component_utils(spi_tb)

  function new(string name = "spi_tb", uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase); 
    `uvm_info(get_type_name(), "Executing spi_tb build_phase()", UVM_HIGH)
    
    wb = wb_env::type_id::create("wb", this);
    spi = spi_env::type_id::create("spi", this);
    sb = spi_scoreboard::type_id::create("sb", this);
    spi_start_event = new("spi_start_event");
    mcsequencer = spi_mcsequencer::type_id::create("mcsequencer", this);

    uvm_config_db#(uvm_event)::set(this, "wb.agent.monitor", "spi_start_event", spi_start_event);
    uvm_config_db#(uvm_event)::set(this, "spi.agent.driver", "spi_start_event", spi_start_event);
    uvm_config_db#(uvm_event)::set(this, "spi.agent.monitor", "spi_start_event", spi_start_event);

  endfunction

  virtual function void connect_phase(uvm_phase phase);
  super.connect_phase(phase);

  //Connect the sequencers and analysis ports to the scoreboard
  mcsequencer.wb_seqr = wb.agent.sequencer;
  mcsequencer.spi_seqr = spi.agent.sequencer;

  wb.agent.monitor.item_collected_port.connect(sb.wb_mon_imp);

  spi.agent.monitor.item_collected_port.connect(sb.spi_imp);

  spi.agent.driver.item_collected_port.connect(sb.spi_driv_imp);

endfunction

  function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
endfunction

endclass