class spi_mcsequencer extends uvm_sequencer;

  `uvm_component_utils(spi_mcsequencer)

  spi_sequencer spi_seqr;
  wb_sequencer wb_seqr;

  function new(string name = "spi_mcsequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction

endclass