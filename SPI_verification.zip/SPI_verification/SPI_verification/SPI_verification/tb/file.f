
-64
-timescale 1ns/1ns
-uvmhome /home/cc/mnt/XCELIUM2309/tools/methodology/UVM/CDNS-1.1d

spi_comm_pkg.sv

-incdir ../DUT
../DUT/simple_spi_top.v
../DUT/fifo4.v

-incdir ../Wishbone_UVC/sv
../Wishbone_UVC/sv/wb_pkg.sv
../Wishbone_UVC/sv/wb_if.sv

-incdir ../SPI_UVC/sv
../SPI_UVC/sv/spi_pkg.sv
../SPI_UVC/sv/spi_if.sv
spi_scoreboard.sv

clkgen.sv

hw_top_dut.sv
tb_top.sv


+UVM_TESTNAME=fifo_rfull_test
+UVM_VERBOSITY=UVM_HIGH









