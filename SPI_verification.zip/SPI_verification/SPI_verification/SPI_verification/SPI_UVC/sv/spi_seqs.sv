class spi_base_seq extends uvm_sequence #(spi_transaction);

  
  `uvm_object_utils(spi_base_seq)
   spi_transaction req;
  // Constructor
  function new(string name="spi_base_seq");
    super.new(name);
  endfunction

  task pre_body();
    uvm_phase phase;
    `ifdef UVM_VERSION_1_2
      // in UVM1.2, get starting phase from method
      phase = get_starting_phase();
    `else
      phase = starting_phase;
    `endif
    if (phase != null) begin
      phase.raise_objection(this, get_type_name());
      `uvm_info(get_type_name(), "raise objection", UVM_MEDIUM)
    end
  endtask : pre_body

  task post_body();
    uvm_phase phase;
    `ifdef UVM_VERSION_1_2
      // in UVM1.2, get starting phase from method
      phase = get_starting_phase();
    `else
      phase = starting_phase;
    `endif
    if (phase != null) begin
      phase.drop_objection(this, get_type_name());
      `uvm_info(get_type_name(), "drop objection", UVM_MEDIUM)
    end
  endtask : post_body

endclass

class spi_seq extends spi_base_seq;

  `uvm_object_utils(spi_seq)

  function new(string name="spi_seq");
    super.new(name);
  endfunction

  task body();
  //repeat(2)
  //repeat(3)   //multibyte transfer
  repeat(4)   //for full fifo test
      `uvm_do(req)
  endtask

endclass
