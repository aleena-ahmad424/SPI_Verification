class spi_driver extends uvm_driver #(spi_transaction);

//Component handles
virtual spi_if vif;
int num_sent;
spi_mode_config mode_cfg;
uvm_event spi_start_event;

//Analysis port to send transaction to scoreboard
uvm_analysis_port #(spi_transaction) item_collected_port;
`uvm_component_utils(spi_driver)

//Constructor
  function new(string name = "spi_driver", uvm_component parent);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);

  endfunction

  //Build phase
  function void build_phase(uvm_phase phase);
    
    super.build_phase(phase);

    //Get SPI mode configuration
    if(!uvm_config_db#(spi_mode_config)::get(this, "", "mode_cfg", mode_cfg))
      `uvm_error("NO_CFG", "SPI mode config not found")

    if(!uvm_config_db#(uvm_event)::get(this, "", "spi_start_event", spi_start_event))
      `uvm_error("NO_EVENT","No event found")
  endfunction
 
//Connect phase 
  function void connect_phase(uvm_phase phase);

    super.connect_phase(phase);
    if (!spi_vif_config::get(this, "", "vif", vif))
      `uvm_error("NOVIF", "vif not set")
  
  endfunction

//Run phase
  task run_phase(uvm_phase phase);
     get_and_drive();
  endtask

  task get_and_drive();
      spi_start_event.wait_trigger();
  forever begin

      seq_item_port.get_next_item(req);

    `uvm_info("MODE_DEBUG", $sformatf("Driver mode CPOL=%0b CPHA=%0b", mode_cfg.cpol, mode_cfg.cpha), UVM_LOW)
    
    `uvm_info("SPI_DRIVER", $sformatf("SPI Sending Transaction:\n%s", req.sprint()), UVM_LOW)  
    
    //Mode 0
    if(!mode_cfg.cpol && !mode_cfg.cpha) begin
      
      for(int i=7;i>=0;i--) begin
      vif.miso <= req.tx_data[i];
      @(negedge vif.sck);
      end
    end
    
    //Mode 1
    else if (!mode_cfg.cpol && mode_cfg.cpha) begin
      
      //Send the bits on the miso line on the rising edge of sck
      for(int i=7;i>=0;i--) begin
        @(posedge vif.sck);
        vif.miso <= req.tx_data[i];
      end
    end

    //Mode 2
    else if (mode_cfg.cpol && !mode_cfg.cpha) begin
       
      //Send the rest of the bits on the miso line on the rising edge of sck
      for (int i = 7; i >= 0; i--) begin
        vif.miso <= req.tx_data[i];
        @(posedge vif.sck);
      end
    end

    //Mode 3
    else begin
      
      //Send the bits on the miso line on the falling edge of sck
      for (int i = 7; i >= 0; i--) begin
          @(negedge vif.sck);
          vif.miso <= req.tx_data[i];
      end
    end
    //Send the transaction to the scoreboard, signal that the item is done and increment the number of transactions sent
    item_collected_port.write(req);
    seq_item_port.item_done();

    num_sent++;
     //end
  end

endtask
function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(
    get_type_name(),
    "Running Simulation ...",
    UVM_HIGH
  )
endfunction

  // UVM report_phase
  function void report_phase(uvm_phase phase);
    `uvm_info(get_type_name(), $sformatf("Report: SPI driver sent %0d transaction", num_sent), UVM_LOW)
  endfunction : report_phase

endclass