class spi_monitor extends uvm_monitor;

//Declare handles
virtual spi_if vif;
spi_transaction tr;
spi_mode_config mode_cfg;
int num_tr_col; 
uvm_event spi_start_event;
//Analysis port to send transaction to subscribers  
uvm_analysis_port #(spi_transaction) item_collected_port;
`uvm_component_utils(spi_monitor)

//Constructor
  function new(string name = "spi_monitor", uvm_component parent);
    
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);

  endfunction
  
  //Build phase
  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase); 

    //Get SPI mode configuration
    if(!uvm_config_db#(spi_mode_config)::get(this, "", "mode_cfg", mode_cfg))
      `uvm_error("NO_CFG", "SPI mode config not found")
    
    if(!uvm_config_db#(uvm_event)::get(this, "", "spi_start_event", spi_start_event))
      `uvm_error("NO_EVENT","No event found")

  endfunction
  
//Connect phase
  function void connect_phase(uvm_phase phase);
  super.connect_phase(phase);

  if (!spi_vif_config::get(this, "", "vif", vif))
    `uvm_error("NOVIF", "vif not set")
  endfunction

//Run phase
task run_phase(uvm_phase phase);

  `uvm_info(get_type_name(), "Detected Reset Done", UVM_MEDIUM)
  spi_start_event.wait_trigger();
  forever begin
    tr = spi_transaction::type_id::create("tr", this);

    //Measure the SCK period
    fork
      measure_sck();
    join_none
    for (int i = 7; i >= 0; i--) begin
      if (!mode_cfg.cpol && !mode_cfg.cpha) begin
         //Sample mode 0
        @(posedge vif.sck);
      end

      else if (!mode_cfg.cpol && mode_cfg.cpha) begin
        //Sample mode 1
        @(negedge vif.sck);
      end

      else if (mode_cfg.cpol && !mode_cfg.cpha) begin
        //Sample mode 2
        @(negedge vif.sck);
      end

      else begin
        //Sample mode 3
        @(posedge vif.sck);
      end

      tr.rx_data[i] = vif.mosi;
      tr.tx_data[i] = vif.miso;

    end
    `uvm_info(get_type_name(), $sformatf("SPI Transaction Collected:\n%s", tr.sprint()), UVM_LOW)

  item_collected_port.write(tr);
  num_tr_col++;
  end

endtask

task measure_sck();

  time t1;
  time t2;

  @(posedge vif.sck);
  t1 = $time;

  @(posedge vif.sck);
  t2 = $time;

  `uvm_info("SPI_CLK", $sformatf("SCK period = %0.0f", t2-t1), UVM_LOW)

endtask

  function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
endfunction

  // UVM report_phase
  function void report_phase(uvm_phase phase);
    `uvm_info(get_type_name(), $sformatf("Report: SPI Monitor Collected %0d Transactions", num_tr_col), UVM_LOW)
  endfunction

endclass