class spi_env extends uvm_env;

  //Agent handle
  spi_agent agent;

  //Factory registration
  `uvm_component_utils(spi_env)

  //Constructor
  function new(string name = "spi_env", uvm_component parent);
    super.new(name, parent);
  endfunction

  //Build phase
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    //Construct the agent
    agent = spi_agent::type_id::create(
                 "agent", this);
  endfunction

  function void start_of_simulation_phase(uvm_phase phase);
  super.start_of_simulation_phase(phase);

  `uvm_info(get_type_name(), "Running Simulation ...", UVM_HIGH)
endfunction

endclass