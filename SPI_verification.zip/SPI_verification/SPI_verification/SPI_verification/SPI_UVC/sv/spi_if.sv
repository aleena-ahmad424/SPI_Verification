interface spi_if #(
  parameter SS_WIDTH = 1
)(input logic clk, input logic rst);
timeunit 1ns;
timeprecision 100ps;

  logic       sck;         // serial clock output
  logic       mosi;        // MasterOut SlaveIN
  logic       miso;         // MasterIn SlaveOut
  
endinterface

